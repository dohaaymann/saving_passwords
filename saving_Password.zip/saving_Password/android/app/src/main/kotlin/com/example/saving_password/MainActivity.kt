package com.example.saving_password

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
